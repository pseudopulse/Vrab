# Vrab

Adds the simulacrum vrab as a playable character.

![preview](https://i.postimg.cc/wjkTJ1rk/01-59-56-screenshot.png)